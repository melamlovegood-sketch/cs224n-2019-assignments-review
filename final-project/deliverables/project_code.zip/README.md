# Calibrated DistilBERT for SQuAD 2.0

This directory contains the reproducible experiment for the CS224N default
final project. It preserves the original Stanford BiDAF starter code in the
parent directory and adds a modern pretrained-contextual-embedding (PCE)
experiment.

## Research question

How much do SQuAD 2.0 fine-tuning and held-out no-answer threshold calibration
improve a compact extractive QA model originally trained only on SQuAD 1.1?

## Method

1. Evaluate `distilbert/distilbert-base-cased-distilled-squad` as the baseline.
2. Fine-tune the same model on a seeded SQuAD 2.0 training subset.
3. Tune the no-answer score threshold on a disjoint calibration subset.
4. Report Exact Match, token F1, answerable-only metrics, and unanswerable
   accuracy on a held-out evaluation subset.
5. Save predictions, plots, timing, and qualitative error-analysis examples.

## Run

```powershell
python test_experiment.py
python experiment.py --smoke
python experiment.py
```

The full run defaults to 12,000 training examples, 1,500 calibration examples,
and 1,500 held-out evaluation examples for two epochs. All splits are selected
with seed 224. Outputs are written under `project/results`, while the trained
checkpoint is written under `project/model`.

## Important outputs

- `project/results/results.json`: configuration, environment, metrics, timing.
- `project/results/training_history.json`: loss and learning-rate history.
- `project/results/error_analysis.json`: selected improvements and regressions.
- `project/results/metric_comparison.png`: EM/F1 comparison.
- `project/results/training_loss.png`: optimization trace.
- `project/model/`: final fine-tuned model and tokenizer.

The code intentionally keeps calibration and final evaluation examples
separate. This prevents selecting the no-answer threshold on the same examples
used for the reported final score.
